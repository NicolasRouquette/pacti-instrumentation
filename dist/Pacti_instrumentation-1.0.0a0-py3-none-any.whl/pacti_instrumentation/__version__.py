"""
Set the Pacti package version in this file
"""

__version__ = '1.0.0.alpha'
